import pygame
import random
import time
import sys
import subprocess
import os

pygame.init()

width = 1280
height = 660
card_width = 60
card_height = 80
WHITE = (255, 255, 255)
BLACK = (0,0,0)

def load_img(img):
    file_path = os.path.join("images",img)
    return file_path


font = pygame.font.Font(None, 36)

clock = pygame.time.Clock()
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Snail Space")

board = pygame.image.load(load_img("bg.jpg"))
board = pygame.transform.scale(board, (width, height))

suits = ["clubs", "diamonds", "hearts", "spades"]

numbers = {
    "ace": 1,
    "2": 2,
    "3": 3,
    "4": 4,
    "5": 5,
    "6": 6,
    "7": 7,
    "8": 8,
    "9": 9,
    "10": 10,
    "jack": 11,
    "queen": 12,
    "king": 13
}

number = list(numbers.keys())
values = list(numbers.values())

deck = []
center_cards = []
player_hand = []
cpu_hand = []
fps = 30

player_score =0
cpu_score = 0


for suit in suits:
    for rank in number:
        card_image = pygame.image.load(load_img(f"{rank}_of_{suit}.png"))
        card_image = pygame.transform.scale(card_image, (card_width, card_height))
        card = {"suit": suit, "rank": numbers[rank], "image": card_image}
        deck.append(card)



def back_card(degree):
    back = pygame.image.load(load_img("back.jpg"))
    back = pygame.transform.scale(back,(card_width,card_height))
    back = pygame.transform.rotate(back,degree)
    return back


def cpu1_back(n):
    for i in range(n):
        screen.blit(back_card(90), (1140 ,(i*0.4* card_height) + 90))

random.shuffle(deck)
for i in range(25):
    center_cards.append(deck.pop())


center = random.sample(deck, 25)
card_images = [card["image"] for card in center]



for i in range(13):
    player_hand.append(deck.pop())
    cpu_hand.append(deck.pop())


back_photo = pygame.image.load(load_img("back.jpg"))
back_photo = pygame.transform.scale(back_photo, (card_width, card_height))

def center_card(card, row, col):
    x = 300 + col * (card_width + 10)
    y = 50 + row * (card_height + 10)
    screen.blit(back_photo, (x, y))

    if card is not None:
        screen.blit(card["image"], (x, y))
    else:
        screen.blit(back_photo, (x, y))



def check_pair(row, col, placed_card_rank):
    # Check the card to the right
    if col + 1 < grid_size:
        right_card = table_cards[row * grid_size + col + 1]
        if right_card is not None and right_card["rank"] == placed_card_rank:
            return True

    # Check the card to the left
    if col - 1 >= 0:
        left_card = table_cards[row * grid_size + col - 1]
        if left_card is not None and left_card["rank"] == placed_card_rank:
            return True

    # Check the card below
    if row + 1 < grid_size:
        bottom_card = table_cards[(row + 1) * grid_size + col]
        if bottom_card is not None and bottom_card["rank"] == placed_card_rank:
            return True

    # Check the card above
    if row - 1 >= 0:
        top_card = table_cards[(row - 1) * grid_size + col]
        if top_card is not None and top_card["rank"] == placed_card_rank:
            return True

    return False



def check_prial(row, col, placed_card_rank):
    # Define a helper function to count consecutive cards with the same rank in a direction
    def count_consecutive_cards_in_direction(dx, dy):
        consecutive_count = 1
        x, y = col, row
        while True:
            x += dx
            y += dy
            if x < 0 or x >= grid_size or y < 0 or y >= grid_size:
                break  # Reached the edge of the grid
            neighbor_card = table_cards[y * grid_size + x]
            if neighbor_card is None or neighbor_card["rank"] != placed_card_rank:
                break  # Neighbor card is empty or has a different rank
            consecutive_count += 1
            if consecutive_count == 3:
                return True  # Found a group of three cards with the same rank
        return False

    # Check for groups of three cards with the same rank in all directions
    if count_consecutive_cards_in_direction(1, 0) or \
       count_consecutive_cards_in_direction(-1, 0) or \
       count_consecutive_cards_in_direction(0, 1) or \
       count_consecutive_cards_in_direction(0, -1):
        print("Prial")
        return True  # Group of three cards with the same rank found
    else:
        return False  # Group of three cards with the same rank not found




def check_double_pair_royal(row, col, placed_card_rank):
    # Define a helper function to count consecutive cards with the same rank in a direction
    def count_consecutive_cards_in_direction(dx, dy):
        consecutive_count = 1
        x, y = col, row
        while True:
            x += dx
            y += dy
            if x < 0 or x >= grid_size or y < 0 or y >= grid_size:
                break  # Reached the edge of the grid
            neighbor_card = table_cards[y * grid_size + x]
            if neighbor_card is None or neighbor_card["rank"] != placed_card_rank:
                break  # Neighbor card is empty or has a different rank
            consecutive_count += 1
            if consecutive_count == 4:
                return True  # Found a group of four cards with the same rank
        return False

    # Check for groups of four cards with the same rank in all directions
    if (placed_card_rank == 11 or placed_card_rank == 12 or placed_card_rank == 13) and \
       (count_consecutive_cards_in_direction(1, 0) or
        count_consecutive_cards_in_direction(-1, 0) or
        count_consecutive_cards_in_direction(0, 1) or
        count_consecutive_cards_in_direction(0, -1)):
        print("Double pair")
        return True  # Group of four cards with the same rank found
    else:
        return False  # Group of four cards with the same rank not found
    

def run_for3(row, col, placed_card_rank):
    # Define a helper function to check if there is a sequence of three consecutive ranks
    def check_sorted_sequence_in_direction(dx, dy):
        sequence_ranks = [placed_card_rank]
        x, y = col, row
        while True:
            x += dx
            y += dy
            if x < 0 or x >= grid_size or y < 0 or y >= grid_size:
                break  # Reached the edge of the grid
            neighbor_card = table_cards[y * grid_size + x]
            if neighbor_card is None:
                break  # Neighbor card is empty
            neighbor_rank = neighbor_card["rank"]
            sequence_ranks.append(neighbor_rank)
        sequence_ranks.sort()
        return sequence_ranks == list(range(sequence_ranks[0], sequence_ranks[0] + 3))

    # Check for series of three cards forming a sequence in all directions
    if check_sorted_sequence_in_direction(1, 0) or \
       check_sorted_sequence_in_direction(-1, 0) or \
       check_sorted_sequence_in_direction(0, 1) or \
       check_sorted_sequence_in_direction(0, -1):
        print("Run 3")
        return True
    else:
        return False





def run_for4(row, col, placed_card_rank):
    # Define a helper function to check if a list of ranks forms a sequence of four consecutive ranks
    def check_sorted_sequence_in_direction(dx, dy, length):
        sequence_ranks = [placed_card_rank]
        x, y = col, row
        while True:
            x += dx
            y += dy
            if x < 0 or x >= grid_size or y < 0 or y >= grid_size:
                break  # Reached the edge of the grid
            neighbor_card = table_cards[y * grid_size + x]
            if neighbor_card is None:
                break  # Neighbor card is empty
            neighbor_rank = neighbor_card["rank"]
            sequence_ranks.append(neighbor_rank)
        sequence_ranks.sort()
        return sequence_ranks == list(range(sequence_ranks[0], sequence_ranks[0] + length))

    # Check for series of four cards forming a sequence in all directions
    if check_sorted_sequence_in_direction(1, 0, 4) or \
       check_sorted_sequence_in_direction(-1, 0, 4) or \
       check_sorted_sequence_in_direction(0, 1, 4) or \
       check_sorted_sequence_in_direction(0, -1, 4):
        print("Run 4")
        return True
    else:
        return False
    



def run_for5(row, col, placed_card_rank):
    # Get the ranks of neighboring cards in the same row
    def check_sorted_sequence_in_direction(dx, dy, length):
        sequence_ranks = [placed_card_rank]
        x, y = col, row
        while True:
            x += dx
            y += dy
            if x < 0 or x >= grid_size or y < 0 or y >= grid_size:
                break  # Reached the edge of the grid
            neighbor_card = table_cards[y * grid_size + x]
            if neighbor_card is None:
                break  # Neighbor card is empty
            neighbor_rank = neighbor_card["rank"]
            sequence_ranks.append(neighbor_rank)
        sequence_ranks.sort()
        return sequence_ranks == list(range(sequence_ranks[0], sequence_ranks[0] + length))

    # Check for series of five cards forming a sequence in all directions
    if check_sorted_sequence_in_direction(1, 0, 5) or \
       check_sorted_sequence_in_direction(-1, 0, 5) or \
       check_sorted_sequence_in_direction(0, 1, 5) or \
       check_sorted_sequence_in_direction(0, -1, 5):
        print("Run 5")
        return True
    else:
        return False




def flush3(row, col, placed_card_suit):
    # Define a helper function to count consecutive cards with the same suit in a direction
    def count_consecutive_same_suit_in_direction(dx, dy):
        consecutive_count = 1
        x, y = col, row
        while True:
            x += dx
            y += dy
            if x < 0 or x >= grid_size or y < 0 or y >= grid_size:
                break  # Reached the edge of the grid
            neighbor_card = table_cards[y * grid_size + x]
            if neighbor_card is None or neighbor_card["suit"] != placed_card_suit:
                break  # Neighbor card is empty or has a different suit
            consecutive_count += 1
            if consecutive_count == 3:
                return True  # Found a group of three cards with the same suit
        return False

    # Check for groups of three cards with the same suit in all directions
    if count_consecutive_same_suit_in_direction(1, 0) or \
       count_consecutive_same_suit_in_direction(-1, 0) or \
       count_consecutive_same_suit_in_direction(0, 1) or \
       count_consecutive_same_suit_in_direction(0, -1):
        print("Flush 3")
        return True  # Group of three cards with the same suit found
    else:
        return False  # Group of three cards with the same suit not found





def flush4(row, col, placed_card_suit):
    # Define a helper function to count consecutive cards with the same suit in a direction
    def count_consecutive_same_suit_in_direction(dx, dy):
        consecutive_count = 1
        x, y = col, row
        while True:
            x += dx
            y += dy
            if x < 0 or x >= grid_size or y < 0 or y >= grid_size:
                break  # Reached the edge of the grid
            neighbor_card = table_cards[y * grid_size + x]
            if neighbor_card is None or neighbor_card["suit"] != placed_card_suit:
                break  # Neighbor card is empty or has a different suit
            consecutive_count += 1
            if consecutive_count == 4:
                return True  # Found a group of four cards with the same suit
        return False

    # Check for groups of four cards with the same suit in all directions
    if count_consecutive_same_suit_in_direction(1, 0) or \
       count_consecutive_same_suit_in_direction(-1, 0) or \
       count_consecutive_same_suit_in_direction(0, 1) or \
       count_consecutive_same_suit_in_direction(0, -1):
        print("Flush 4")
        return True  # Group of four cards with the same suit found
    else:
        return False  # Group of four cards with the same suit not found
    




def flush5(row, col, placed_card_suit):
    # Define a helper function to count consecutive cards with the same suit in a direction
    def count_consecutive_same_suit_in_direction(dx, dy):
        consecutive_count = 1
        x, y = col, row
        while True:
            x += dx
            y += dy
            if x < 0 or x >= grid_size or y < 0 or y >= grid_size:
                break  # Reached the edge of the grid
            neighbor_card = table_cards[y * grid_size + x]
            if neighbor_card is None or neighbor_card["suit"] != placed_card_suit:
                break  # Neighbor card is empty or has a different suit
            consecutive_count += 1
            if consecutive_count == 5:
                return True  # Found a group of five cards with the same suit
        return False

    # Check for groups of five cards with the same suit in all directions
    if count_consecutive_same_suit_in_direction(1, 0) or \
       count_consecutive_same_suit_in_direction(-1, 0) or \
       count_consecutive_same_suit_in_direction(0, 1) or \
       count_consecutive_same_suit_in_direction(0, -1):
        print("Flush 5")
        return True  # Group of five cards with the same suit found
    else:
        return False  # Group of five cards with the same suit not found
    



def text_screen(message,posx,posy):
    text = font.render(message, True, BLACK)  # Render text, antialiasing, color
    text_rect = text.get_rect()

    # Set the position of the text rectangle
    text_rect.center = (posx, posy)

    # Blit the text onto the window surface
    screen.blit(text, text_rect)




def check_win(a,b):
    if player_score>cpu_score:
        text_screen("Player Won!!!",a,b)
    elif player_score<cpu_score:
        text_screen("CPU Won!!!",a,b)
    else:
        text_screen("DRAW!!!",a,b)

    # time.sleep(2)



def cpu_turn():
    global cpu_hand,turn,table_cards,cpu_score
    ran_card = random.choice(cpu_hand)
    cpu_hand.remove(ran_card)
    cpu1_back(len(cpu_hand))
    screen.blit(ran_card["image"],(1100,300))
    table_cards.append(ran_card)

    for position in fixed_positions:
        row, col = position
        index = row * grid_size + col
        if table_cards[index] is None:
            table_cards[index] = ran_card
            break

    

    if check_pair(row, col, ran_card["rank"]):
        print("Pair cpu")
        cpu_score+=2
    
    if check_prial(row,col,ran_card["rank"]):
        cpu_score+=6
    
    if check_double_pair_royal(row,col,ran_card["rank"]):
        cpu_score+=12
            
    if run_for3(row,col,ran_card["rank"]):
        cpu_score+=3

    if run_for4(row,col,ran_card["rank"]):
        cpu_score+=4

    if run_for5(row,col,ran_card["rank"]):
        cpu_score+=5

    if flush3(row,col,ran_card["suit"]):
        cpu_score+=3

    if flush4(row,col,ran_card["suit"]):
        cpu_score+=4

    if flush5(row,col,ran_card["suit"]):
        cpu_score+=5
        
    clock.tick(fps)
    turn =1



grid_size = 5  # Assuming a 5x5 grid
grid = [[None for _ in range(grid_size)] for _ in range(grid_size)]

table_cards = [None] * (grid_size * grid_size)
fixed_positions = [(2, 2), (2,3),(3,3),(3,2),(3,1),(2,1),(1,1),(1,2),(1,3),(1,4),(2,4),(3,4),(4,4),(4,3),(4,2),(4,1),(4,0),(3,0),(2,0),(1,0),(0,0),(0,1),(0,2),(0,3),(0,4)]  # Fixed positions list

# Display images
image_index = 0
running = True
turn = 2
selected_card = None
# Main loop

# Initialize table_cards with None values

# Main loop
while running:
    screen.fill(WHITE)
    screen.blit(board, (0, 0))
    cpu1_back(len(cpu_hand))

    # Display player's hand
    for i, card in enumerate(player_hand):
        card_rect = pygame.Rect((i * 1.10 * card_width) + 180, 540, card_width, card_height)
        screen.blit(card['image'], card_rect)

    if turn == 1:
        time.sleep(0.5)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = pygame.mouse.get_pos()

                for i, card in enumerate(player_hand):
                    x = (i * 1.10 * card_width) + 180
                    y = 540
                    card_rect = pygame.Rect((i * 1.10 * card_width) + 180, 540, card_width, card_height)

                    if x <= mouse_x < x + card_width and y <= mouse_y < y + card_height:
                        turn=2
                        pygame.draw.rect(screen, (255, 0, 0), card_rect, 3)
                        pygame.display.update()
                        selected_card = player_hand.pop(i)

                        # Update table_cards with the selected card at the correct position
                        for position in fixed_positions:
                            row, col = position
                            index = row * grid_size + col
                            if table_cards[index] is None:
                                table_cards[index] = selected_card
                                break

                        if check_pair(row, col, selected_card["rank"]):
                            print("Pair")
                            player_score+=2

                        if check_prial(row,col,selected_card["rank"]):
                            player_score+=6

                        if check_double_pair_royal(row,col,selected_card["rank"]):
                            player_score+=12

                        if run_for3(row,col,selected_card["rank"]):
                            player_score+=3

                        if run_for4(row,col,selected_card["rank"]):
                            player_score+=4

                        if run_for5(row,col,selected_card["rank"]):
                            player_score+=5

                        if flush3(row,col,selected_card["suit"]):
                            player_score+=3

                        if flush4(row,col,selected_card["suit"]):
                            player_score+=4

                        if flush5(row,col,selected_card["suit"]):
                            player_score+=5

    elif turn ==2:
        time.sleep(0.5)
        cpu_turn()
        clock.tick(30)


    # Display table_cards in the fixed positions
    for i, position in enumerate(fixed_positions):
        row, col = position
        card = table_cards[row * grid_size + col]
        center_card(card, row, col)


    text_screen(f"Player Score: {player_score}",130,30)
    text_screen(f"CPU Score: {cpu_score}",width - 190,30)
    
    if len(cpu_hand)==0:
        check_win(900, 300)
        pygame.display.flip()  # Update the display
        pygame.time.wait(7000)
        subprocess.Popen(["python", "main.py"])
        pygame.quit()
        sys.exit()

    clock.tick(fps)
    # Update the display
    pygame.display.flip()
