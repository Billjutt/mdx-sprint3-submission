import pygame
import subprocess
import sys
import os

# Initialize Pygame
pygame.init()

# Set up the window
WIDTH, HEIGHT = 800, 600
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Main Menu")

# Load background image
path_img = os.path.join("images","table.jpg")
background_image = pygame.image.load(path_img).convert_alpha()
background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT))

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
GRAY = (128, 128, 128)

# Fonts
font = pygame.font.Font(None, 48)

# Define Button class
class Button:
    def __init__(self, x, y, width, height, text, color, hover_color, action=None):
        self.rect = pygame.Rect(x, y, width, height)
        self.color = color
        self.hover_color = hover_color
        self.text = text
        self.action = action
        self.hovered = False

    def draw(self, surface):
        # Change color if hovered
        color = self.hover_color if self.hovered else self.color
        pygame.draw.rect(surface, color, self.rect)
        pygame.draw.rect(surface, BLACK, self.rect, 2)

        # Render text
        text_surface = font.render(self.text, True, BLACK)
        text_rect = text_surface.get_rect(center=self.rect.center)
        surface.blit(text_surface, text_rect)

    def update(self, mouse_pos):
        self.hovered = self.rect.collidepoint(mouse_pos)

# Create buttons
button_cpu = Button(250, 150, 300, 80, "Single Player", RED, GREEN, action="cpu")
button_player = Button(250, 250, 300, 80, "MultiPlayer", RED, GREEN, action="player")
button_exit = Button(250, 350, 300, 80, "Exit", RED, GREEN, action="exit")

buttons = [button_cpu,button_player, button_exit]


def file_path(file):
    game = os.path.join("games",file)
    return game

# Main loop
running = True
while running:
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                for button in buttons:
                    if button.rect.collidepoint(event.pos):
                        if button.action == "cpu":
                            subprocess.Popen(["python", file_path("cpu.py")])
                            pygame.quit()
                            sys.exit()
                        elif button.action == "player":
                            subprocess.Popen(["python", file_path("multiplayer.py")])
                            pygame.quit()
                            sys.exit()
                            
                        elif button.action == "exit":
                            running = False

    # Update buttons
    mouse_pos = pygame.mouse.get_pos()
    for button in buttons:
        button.update(mouse_pos)

    # Draw everything
    window.blit(background_image, (0, 0))
    for button in buttons:
        button.draw(window)
    pygame.display.flip()

# Quit Pygame
pygame.quit()
sys.exit()
